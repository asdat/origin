Template Name: NewsFeed
Template URI: http://www.wpfreeware.com/newsfeed-ultra-responsive-news-magazine-theme/
Author: WpFreeware
Author URI: http://www.wpfreeware.com
Description: A Pro Bootstrap Magazine style website template
Version: 1.0 
License: CC 4.0
License URI: http://creativecommons.org/licenses/by/4.0/



---------------------------------------------
Find more great resources @ WpFreeware.com
Sincerely,
WpFreeware
---------------------------------------------
PS. Those terms might change as we update our license on our website, 
please be sure to check the latest license terms (http://www.wpfreeware.com/terms-use/) 
on our website to avoid any misuse of our resources.

Thank you!